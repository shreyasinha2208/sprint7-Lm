package com.cg.ibs.loanmgmt.services;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.TransactionBean;

public interface PayEmiService {
	List<LoanMaster> getApprovedLoanListByUci(CustomerBean customer);

	LoanMaster getLoanByLoanNum(BigInteger loanAccountNumber);

	LoanMaster updateLoanPostEmi(LoanMaster globalLoanMaster);

	TransactionBean createDebitTransaction(LoanMaster globalLoanMaster);

	TransactionBean createCreditTransaction(LoanMaster globalLoanMaster);

	CustomerBean getCustomer(String userId);
}
