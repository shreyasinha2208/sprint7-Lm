package com.cg.ibs.loanmgmt.repositories;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;

public interface LoanMasterDao {
	LoanMaster applyLoan(LoanMaster loanMaster);

	LoanMaster applyingLoan(LoanMaster loanMaster);

	public LoanMaster updateBalanceDao(LoanMaster loanMaster);

	List<LoanMaster> getSentForVerificationLoans();
	
	List<LoanMaster> getSentForVerificationPreclosure();

	LoanMaster updateLoanApprovalDao(LoanMaster loanMasterTemp);

	LoanMaster updateLoanDenialDao(LoanMaster loanMasterTemp);

	List<LoanMaster> getPendingPreClosures();

	LoanMaster updatePreClosureApprovalDao(LoanMaster loanMasterTemp);

	List<LoanMaster> getLoanListByUci(CustomerBean customer);

	List<LoanMaster> getApprovedLoanListByUci(CustomerBean customer);

	public LoanMaster getLoanByLoanNumber(BigInteger loanAccNum);

	public void updatePreClosureDao(LoanMaster loanMaster);

	LoanMaster getLoanByApplicantNumber(BigInteger applicantNum);

	LoanMaster updatePreClosureDenialDao(LoanMaster loanMasterTemp);

	BigInteger getMaxApplicationNumber();

	LoanMaster sendLoanForVerification(LoanMaster globalLoanMaster);

	LoanMaster updateLoanForVerification(LoanMaster globalLoanMaster);

	public List<LoanMaster> getAllLoans();

	void updateLoanBankAdminApprover(List<LoanMaster> updatedLoans);

	// LoanMaster payEmi(CustomerBean customer, LoanMaster loanMaster);

}
