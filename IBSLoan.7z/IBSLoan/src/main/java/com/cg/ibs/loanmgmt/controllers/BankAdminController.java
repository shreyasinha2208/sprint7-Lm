package com.cg.ibs.loanmgmt.controllers;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder.Case;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanStatus;
import com.cg.ibs.loanmgmt.services.ApplyLoanService;
import com.cg.ibs.loanmgmt.services.BankAdminService;
import com.cg.ibs.loanmgmt.services.CustomerService;
import com.cg.ibs.loanmgmt.services.VerifyLoanService;
import com.cg.ibs.loanmgmt.services.VerifyPreClosureService;

@RestController
@Scope("session")
public class BankAdminController {
	@Autowired
	private BankAdminService bankAdminService;
	@Autowired
	private VerifyLoanService verifyLoanService;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private ApplyLoanService applyLoanService;
	@Autowired
	private VerifyPreClosureService verifyPreclosureService;

	BankAdmins loggedInBankAdmin = new BankAdmins();
	LoanMaster globalLoanMaster = new LoanMaster();

	@GetMapping("/bankAdmin/{userId}")
	public ResponseEntity<String> loginRole(@PathVariable("userId") String userId) {
		ResponseEntity<String> result;
		loggedInBankAdmin = bankAdminService.getBankAdmin(userId);
		if (userId == null) {
			result = new ResponseEntity<>("No User Details Received", HttpStatus.BAD_REQUEST);
		} else {
			result = new ResponseEntity<>("Welcome " + loggedInBankAdmin.getAdminId(), HttpStatus.OK);

		}

		return result;
	}

	@GetMapping("/verifyLoan")
	public ResponseEntity<List<LoanMaster>> viewPendingLoans() {
		ResponseEntity<List<LoanMaster>> result;
		try {
			List<LoanMaster> pendingLoans = verifyLoanService.getSentForVerificationLoans();
			result = new ResponseEntity<List<LoanMaster>>(pendingLoans, HttpStatus.OK);
		} catch (Exception exc) {
			result = new ResponseEntity<List<LoanMaster>>(HttpStatus.BAD_REQUEST);
		}
		return result;
	}

	@GetMapping(value = "/selectLoan/{appNo}")
	public ResponseEntity<LoanMaster> selectLoanVerify(@PathVariable("appNo") BigInteger appNo) {
		List<LoanMaster> pendingLoans = verifyLoanService.getSentForVerificationLoans();
		ResponseEntity<LoanMaster> result;
		LoanMaster selectLoan = null;
		for (LoanMaster loanMaster : pendingLoans) {
			if (loanMaster.getApplicationNumber().equals(appNo)) {
				selectLoan = loanMaster;
				break;
			}
		}
		if (null != selectLoan) {
			result = new ResponseEntity<LoanMaster>(selectLoan, HttpStatus.OK);
		} else {
			result = new ResponseEntity<LoanMaster>(selectLoan, HttpStatus.BAD_REQUEST);
		}
		return result;
	}

	@PutMapping(value = "/loanVerification/{appNo}/{choice}")
	public ResponseEntity<String> updateLoanPostVerify(@PathVariable("appNo") BigInteger appNo,
			@PathVariable("choice") String choice) {
		ResponseEntity<String> result = null;
		LoanMaster loanMaster = verifyLoanService.getLoanByApplicantNum(appNo);
		switch (choice) {
		case "APPROVED":
			loanMaster.setStatus(LoanStatus.APPROVED);
			loanMaster.setApprovedDate(LocalDate.now());
			loanMaster.setNextEmiDate(LocalDate.now().plusMonths(1));
			loanMaster.setTotalNumOfEmis(loanMaster.getLoanTenure());
			loanMaster.setNumOfEmisPaid(0);
			loanMaster.getSavingsAccount().setBalance(loanMaster.getLoanAmount());
			loanMaster = verifyLoanService.updateLoanPostVerify(loanMaster);
			result = new ResponseEntity<String>(
					"Loan has been approved. your loan number is:" + loanMaster.getLoanAccountNumber(), HttpStatus.OK);
			break;
		case "DECLINE":
			loanMaster.setStatus(LoanStatus.DENIED);
			loanMaster = verifyLoanService.updateLoanPostDenial(loanMaster);
			result = new ResponseEntity<String>("Loan has been denied", HttpStatus.OK);
		}
		return result;
	}

	@GetMapping(value = "/verifyPreclosure")
	public ResponseEntity<List<LoanMaster>> viewPendingPreClosure() {
		ResponseEntity<List<LoanMaster>> result;
		try {
			List<LoanMaster> pendingPreclosure = verifyPreclosureService.getSentForVerificationPreclosure();
			result = new ResponseEntity<List<LoanMaster>>(pendingPreclosure, HttpStatus.OK);
		} catch (Exception exc) {
			result = new ResponseEntity<List<LoanMaster>>(HttpStatus.BAD_REQUEST);
		}

		return result;
	}

	@GetMapping(value = "/selectPreClosure/{appNo}")
	public ResponseEntity<LoanMaster> sendCustomerPreClosureDetails(@PathVariable("appNo") BigInteger appNo) {
		ResponseEntity<LoanMaster> result;
		List<LoanMaster> pendingPreclosure = verifyPreclosureService.getSentForVerificationPreclosure();
		LoanMaster selectPreClosure = null;
		for (LoanMaster loanMaster : pendingPreclosure) {
			if (loanMaster.getApplicationNumber().equals(appNo)) {
				selectPreClosure = loanMaster;
				break;
			}
		}
		if (null != selectPreClosure) {
			result = new ResponseEntity<LoanMaster>(selectPreClosure, HttpStatus.OK);
		} else {
			result = new ResponseEntity<LoanMaster>(selectPreClosure, HttpStatus.BAD_REQUEST);
		}
		return result;
	}


	@PutMapping(value = "/preClosureVerify/{appNo}/{choice}")
	public ResponseEntity<String> updatePreClosurePostVerify(@PathVariable("appNo") BigInteger appNo,
			@PathVariable("choice") String choice) {
		ResponseEntity<String> result = null;
		LoanMaster loanMaster = verifyPreclosureService.getLoanByApplicantNum(appNo);
		switch (choice) {
		case "VERIFY":
			loanMaster.setLoanClosedDate(LocalDate.now());
			loanMaster.setStatus(LoanStatus.PRE_CLOSED);
			loanMaster.setBalance(new BigDecimal("0.00"));
			loanMaster.setNextEmiDate(null);
			loanMaster = verifyPreclosureService.updatePreClosurePostVerify(loanMaster);
			result = new ResponseEntity<String>("Your PreClosure has been approved and the details have been updated.",
					HttpStatus.OK);
			break;
		case "DECLINE":
			loanMaster.setStatus(LoanStatus.APPROVED);
			loanMaster.setNextEmiDate(loanMaster.getNextEmiDate());
			loanMaster = verifyLoanService.updateLoanPostDenial(loanMaster);
			result = new ResponseEntity<String>("PreClosure has been denied", HttpStatus.OK);
		}
		return result;
	}

}
