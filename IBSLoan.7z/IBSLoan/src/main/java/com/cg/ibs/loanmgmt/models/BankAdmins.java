package com.cg.ibs.loanmgmt.models;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Bank_admins")
public class BankAdmins implements Serializable {
	@Id
	@Column(name = "admin_id", nullable = false)
	String adminId;
	@Column(name = "password", nullable = false)
	String password;
	@OneToMany(mappedBy = "adminApprover", fetch = FetchType.LAZY)
	private Set<LoanMaster> loanApplications;

	public String getAdminId() {
		return adminId;
	}

	public Set<LoanMaster> getLoanApplications() {
		return loanApplications;
	}

	public void setLoanApplications(Set<LoanMaster> loanApplications) {
		this.loanApplications = loanApplications;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public BankAdmins() {
		super();
	}
}
