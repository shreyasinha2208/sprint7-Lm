package com.cg.ibs.loanmgmt.services;

import java.math.BigInteger;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.repositories.CustomerDao;
import com.cg.ibs.loanmgmt.repositories.LoanMasterDao;
@Service
public class VerifyPreClosureServiceImpl implements VerifyPreClosureService {
	@Autowired
	private LoanMasterDao loanMasterDao;
	@Autowired
	private CustomerDao custDao;

	@Override
	public List<LoanMaster> getSentForVerificationPreclosure() {
		
		return loanMasterDao.getSentForVerificationPreclosure();
	}

	@Override
	@Transactional
	public LoanMaster updatePreClosurePostVerify(LoanMaster globalLoanMaster) {
		return loanMasterDao.updatePreClosureApprovalDao(globalLoanMaster);
	}

	@Override
	@Transactional
	public LoanMaster updatePreClosurePostDenial(LoanMaster globalLoanMaster) {
		return loanMasterDao.updatePreClosureApprovalDao(globalLoanMaster);
	}

	@Override
	public LoanMaster getLoanByApplicantNum(BigInteger applicantNum) {
		return loanMasterDao.getLoanByApplicantNumber(applicantNum);
		
	}

	@Override
	public CustomerBean getCustomerFromUci(BigInteger uci) {
		return custDao.getCustomerDetailsByUci(uci);
	}

}
